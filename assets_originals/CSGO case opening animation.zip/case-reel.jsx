// Case-opening reel. Swap SYMBOLS for your own: set `img` to an image URL
// (it replaces the letter glyph), keep `tier` for the rarity colour.
const SYMBOLS = [
  { name: 'Symbol A', glyph: 'A', tier: 0 },
  { name: 'Symbol B', glyph: 'B', tier: 0 },
  { name: 'Symbol C', glyph: 'C', tier: 0 },
  { name: 'Symbol D', glyph: 'D', tier: 1 },
  { name: 'Symbol E', glyph: 'E', tier: 1 },
  { name: 'Symbol F', glyph: 'F', tier: 2 },
  { name: 'Symbol G', glyph: 'G', tier: 3 },
  { name: 'Symbol H', glyph: 'H', tier: 4 },
];
const WINNER = 6; // index in SYMBOLS
const TIERS = [
  { label: 'Mil-Spec', color: '#4b69ff' },
  { label: 'Restricted', color: '#8847ff' },
  { label: 'Classified', color: '#d32ce6' },
  { label: 'Covert', color: '#eb4b4b' },
  { label: 'Rare Special', color: '#e4ae39' },
];
const WEIGHTS = [0.62, 0.22, 0.1, 0.045, 0.015];
const MARKER = '#e6c619';
const FONT = 'var(--font-heading, "Archivo", system-ui, sans-serif)';

const W = 1920, H = 1080;
const CELL = 300, GAP = 12, PITCH = CELL + GAP, CELL_H = 220;
const COUNT = 64, START_POS = 4, WIN_INDEX = 54;

function buildReel(winner) {
  let s = 1337;
  const rnd = () => ((s = (s * 16807) % 2147483647) / 2147483647);
  const byTier = t => SYMBOLS.filter(x => x.tier === t);
  const out = [];
  for (let i = 0; i < COUNT; i++) {
    let r = rnd(), t = 0;
    while (t < WEIGHTS.length - 1 && r > WEIGHTS[t]) { r -= WEIGHTS[t]; t++; }
    const pool = byTier(t).length ? byTier(t) : SYMBOLS;
    out.push(pool[Math.floor(rnd() * pool.length)]);
  }
  out[WIN_INDEX] = winner;
  return out;
}

const CURVES = {
  Quart: Easing.easeOutQuart,
  Quint: t => 1 - Math.pow(1 - t, 5),
  Expo: Easing.easeOutExpo,
};
const MOTION = {
  enter: (from, to, start, end) => animate({ from, to, start, end, ease: Easing.easeOutCubic }),
  settle: (from, to, start, end) => animate({ from, to, start, end, ease: Easing.easeInOutCubic }),
  pop: (from, to, start, end) => animate({ from, to, start, end, ease: Easing.easeOutBack }),
};

function Cell({ item, x, dim, glow, lift, mag }) {
  const c = TIERS[item.tier].color;
  return (
    <div style={{
      position: 'absolute', left: x, top: 0, width: CELL, height: CELL_H,
      opacity: dim,
      transform: `translateY(${-lift * 10}px) scale(${mag + lift * 0.05})`,
      transformOrigin: '50% 50%',
      background: `linear-gradient(180deg, rgba(58,58,66,0.92) 0%, rgba(74,74,88,0.92) 45%, color-mix(in srgb, ${c} 55%, rgba(60,60,72,0.92)) 100%)`,
      boxShadow: glow > 0 ? `0 0 ${40 * glow}px ${c}` : 'none',
      display: 'flex', flexDirection: 'column',
    }}>
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        {item.img
          ? <img src={item.img} style={{ maxWidth: '82%', maxHeight: '82%', objectFit: 'contain', filter: 'drop-shadow(0 6px 8px rgba(0,0,0,0.5))' }} />
          : <span style={{ fontFamily: FONT, fontWeight: 800, fontSize: 110, lineHeight: 1, color: '#e8e8ee', textShadow: '0 6px 10px rgba(0,0,0,0.5)' }}>{item.glyph}</span>}
      </div>
      <div style={{ height: 8, background: c }}></div>
    </div>
  );
}

function Piece({ t }) {
  const { T, CUES } = useComposition();
  const winner = SYMBOLS[WINNER];
  const reel = React.useMemo(() => buildReel(winner), []);
  const ease = CURVES[t.curve] || CURVES.Quint;
  const spinEnd = CUES.Reveal;
  const landing = t.landingOffset / PITCH;
  const endPos = WIN_INDEX + landing;

  const posAt = (tt) => {
    const p = clamp((tt - CUES.Spin) / (spinEnd - CUES.Spin), 0, 1);
    let pos = START_POS + (endPos - START_POS) * ease(p);
    if (t.snapToCenter) pos -= landing * MOTION.settle(0, 1, spinEnd + 0.15, spinEnd + 0.75)(tt);
    return pos;
  };
  const pos = posAt(T);
  const vel = Math.abs(posAt(T + 1 / 60) - pos) * PITCH * 60;
  const blur = t.motionBlur ? Math.min(4, vel / 2500) : 0;
  const tx = W / 2 - CELL / 2 - pos * PITCH;

  const reveal = MOTION.pop(0, 1, spinEnd + 0.2, spinEnd + 0.9)(T);
  const out = MOTION.enter(0, 1, CUES.Reset, CUES.Reset + 0.6)(T);
  const fadeIn = MOTION.enter(0, 1, 0, CUES.Spin)(T);
  const alpha = fadeIn * (1 - out);
  const r = reveal * (1 - out);
  const labelIn = MOTION.enter(0, 1, spinEnd + 0.6, spinEnd + 1.2)(T) * (1 - out);
  const reelTop = (H - CELL_H) / 2;
  const fade = 'linear-gradient(90deg, transparent 0%, #000 18%, #000 82%, transparent 100%)';

  return (
    <div style={{ position: 'absolute', inset: 0, overflow: 'hidden', fontFamily: FONT }}>
      <div style={{ position: 'absolute', inset: 0, opacity: alpha }}>
        <div style={{
          position: 'absolute', left: 0, top: reelTop - 40, width: W, height: CELL_H + 80,
          WebkitMaskImage: fade, maskImage: fade,
        }}>
          <div style={{ position: 'absolute', left: 0, top: 40, width: W, height: CELL_H, filter: blur ? `blur(${blur}px)` : 'none' }}>
            {reel.map((item, i) => {
              const x = tx + i * PITCH;
              if (x < -PITCH * 2 || x > W + PITCH) return null;
              const isWin = i === WIN_INDEX;
              const d = Math.abs(x + CELL / 2 - W / 2) / PITCH;
              const mag = t.magnify ? 1 + 0.12 * Math.max(0, 1 - d / 1.4) : 1;
              return <Cell key={i} item={item} x={x} mag={mag}
                dim={isWin ? 1 : 1 - 0.6 * r}
                glow={isWin ? r : 0}
                lift={isWin ? r : 0} />;
            })}
          </div>
        </div>
        <div style={{
          position: 'absolute', left: W / 2 - 2, width: 4, top: reelTop - 30, height: CELL_H + 60,
          background: MARKER, boxShadow: `0 0 8px ${MARKER}`, opacity: 1 - 0.9 * r,
        }}></div>
        <div style={{
          position: 'absolute', left: 0, width: W, top: reelTop + CELL_H + 56,
          opacity: labelIn, transform: `translateY(${(1 - labelIn) * 16}px)`,
          display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6,
          textShadow: '0 2px 8px rgba(0,0,0,0.6)',
        }}>
          <div style={{ fontSize: 26, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: TIERS[winner.tier].color }}>{TIERS[winner.tier].label}</div>
          <div style={{ fontSize: 56, fontWeight: 800, lineHeight: 1, color: '#fff' }}>{winner.name}</div>
        </div>
      </div>
    </div>
  );
}

function CaseReel() {
  const [t, setTweak] = useTweaks(window.TWEAK_DEFAULTS);
  return (
    <>
      <CompositionStage width={W} height={H} scenes={window.OM_SCENES} playback={window.OM_PLAYBACK} bg="transparent">
        <Piece t={t} />
      </CompositionStage>
      <TweaksPanel>
        <TweakSection label="Reel" />
        <TweakRadio label="Curve" value={t.curve} options={['Quart', 'Quint', 'Expo']} onChange={v => setTweak('curve', v)} />
        <TweakSlider label="Landing offset" value={t.landingOffset} min={-140} max={140} unit="px" onChange={v => setTweak('landingOffset', v)} />
        <TweakToggle label="Snap to centre" value={t.snapToCenter} onChange={v => setTweak('snapToCenter', v)} />
        <TweakToggle label="Centre magnify" value={t.magnify} onChange={v => setTweak('magnify', v)} />
        <TweakToggle label="Motion blur" value={t.motionBlur} onChange={v => setTweak('motionBlur', v)} />
        <TweakSection label="Editor" />
        <TweakToggle label="Motion editor" value={t.motionEditor} onChange={v => setTweak('motionEditor', v)} />
      </TweaksPanel>
    </>
  );
}

window.CaseReel = CaseReel;
